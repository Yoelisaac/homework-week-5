﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_Week05_Yoel
{
    public partial class Form1 : Form
    {
        Dictionary<string, int> counters = new Dictionary<string, int>();
        DataTable dt_product = new DataTable();
        DataTable dt_category = new DataTable();
        DataTable dt_filter_product = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt_product.Columns.Add("ID Product");
            dt_product.Columns.Add("Nama Product");
            dt_product.Columns.Add("Harga");
            dt_product.Columns.Add("Stock");
            dt_product.Columns.Add("ID Category");
            dt_product.Rows.Add("J001", "Jas Hitam", "100.000", "10", "C1");
            dt_product.Rows.Add("T001", "T-Shirt Black Pink", "70.000", "20", "C2");
            dt_product.Rows.Add("T002", "T-Shirt Obsessive", "75.000", "16", "C2");
            dt_product.Rows.Add("R001", "Rok Mini", "82.000", "26", "C3");
            dt_product.Rows.Add("J002", "Jeans Biru", "90.000", "5", "C4");
            dt_product.Rows.Add("C001", "Celana Pendek Coklat", "60.000", "11", "C4");
            dt_product.Rows.Add("C002", "Cawat Blink-blink", "1.000.000", "1", "C5");
            dt_product.Rows.Add("R002", "Rocca Shirt", "50.000", "8", "C2");
            dt_category.Columns.Add("ID Category");
            dt_category.Columns.Add("Nama Category");
            dt_category.Rows.Add("C1", "Jas");
            dt_category.Rows.Add("C2", "T-Shirt");
            dt_category.Rows.Add("C3", "Rok");
            dt_category.Rows.Add("C4", "Celana");
            dt_category.Rows.Add("C5", "Cawat");
            dt_filter_product = dt_product.Copy();
            dgv_product.DataSource = dt_filter_product;
            dgv_category.DataSource = dt_category;
            for (int i = 0; i < dt_category.Rows.Count; i++)
            {
                cb_filter.Items.Add(dt_category.Rows[i][1]);
                cb_category.Items.Add(dt_category.Rows[i][1]);
            }
            dgv_product.ClearSelection();
            dgv_category.ClearSelection();
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Text = string.Empty;
            tb_harga.Text = string.Empty;
            tb_namaD.Text = string.Empty;
            tb_stock.Text = string.Empty;
            cb_category.Text = string.Empty;
            tb_namaC.Text = string.Empty;
            for (int i = dgv_product.Rows.Count - 2; i >= 0; i--)
            {
                dgv_product.Rows.RemoveAt(i);
            }
            for (int i = 0; i < dt_product.Rows.Count; i++)
            {
                dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
            }
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
          cb_filter.Enabled = true;
        }

        private void dgv_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_namaD.Text = dgv_product.CurrentRow.Cells[1].Value.ToString();
            tb_harga.Text = dgv_product.CurrentRow.Cells[2].Value.ToString();
            tb_stock.Text = dgv_product.CurrentRow.Cells[3].Value.ToString();
            cb_category.Text = dgv_product.CurrentRow.Cells[4].Value.ToString();
            for (int i = 0; i < dt_category.Rows.Count; i++)
            {
                if (cb_category.Text == dt_category.Rows[i][0].ToString())
                {
                    cb_category.Text = dt_category.Rows[i][1].ToString();
                }
            }
        }

        private void btn_addP_Click(object sender, EventArgs e)
        {
            string number = "1234567890";
            if (tb_namaD.Text.Length != 0 && tb_harga.Text.Length != 0 && tb_stock.Text.Length != 0 && cb_category.Text.Length != 0)
            {
                int periksa = 0;
                foreach (char x in tb_harga.Text)
                {
                    foreach (char y in number)
                    {
                        if (y == x)
                        {
                            periksa++;
                        }
                    }
                }
                if (periksa != tb_harga.Text.Length)
                {
                    MessageBox.Show("Harga tidak valid");
                    return;
                }
                else
                {
                    int stok = int.Parse(tb_stock.Text);
                    if (stok < 0)
                    {
                        MessageBox.Show("Stok tidak boleh kurang dari 0");
                        return;
                    }
                }

                string selectedId = GenerateCode(tb_namaD.Text);
                dt_filter_product.Rows.Add(selectedId, tb_namaD.Text, tb_harga.Text, tb_stock.Text, cb_category.Text);
                dt_product.Rows.Add(selectedId, tb_namaD.Text, tb_harga.Text, tb_stock.Text, cb_category.Text);

                dgv_product.Refresh();
                dgv_product.ClearSelection();
                tb_namaD.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cb_category.Text = "";
            }
            else
            {
                MessageBox.Show("Input tidak lengkap");
            }
        }

        string GenerateCode(string itemName)
        {
            string firstLetter = itemName.Substring(0, 1).ToUpper();
            if (!counters.ContainsKey(firstLetter))
            {
                counters[firstLetter] = 1;
            }
            else
            {
                counters[firstLetter]++;
            }
            return firstLetter + counters[firstLetter].ToString("D3");
        }

        private void dgv_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_namaC.Text = dgv_category.CurrentRow.Cells[1].Value.ToString();
        }

        private void btn_editP_Click(object sender, EventArgs e)
        {
            string angka = "1234567890.";
            if (tb_namaD.Text.Length != 0 || tb_harga.Text.Length != 0 || tb_stock.Text.Length != 0 || cb_category.Text.Length != 0)
            {
                int ceks = 0;
                foreach (char a in tb_harga.Text)
                {
                    foreach (char b in angka)
                    {
                        if (b == a)
                        {
                            ceks++;
                        }
                    }
                }
                if (ceks != tb_harga.Text.Length)
                {
                    MessageBox.Show("Input yang lengkap ya");
                }
                else
                {
                    ceks = 0;
                    foreach (char a in tb_stock.Text)
                    {
                        foreach (char b in angka)
                        {
                            if (b == a)
                            {
                                ceks++;
                            }
                        }
                    }
                    if (ceks != tb_stock.Text.Length)
                    {
                        MessageBox.Show("Input yang lengkap ya");
                    }
                    else
                    {
                        string selectedid = dgv_product.CurrentRow.Cells[0].Value.ToString();
                        for (int i = dgv_product.Rows.Count - 1; i >= 0; i--)
                        {
                            dgv_product.Rows.RemoveAt(i);
                        }
                        for (int i = 0; i < dt_product.Rows.Count; i++)
                        {
                            dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                        }
                        for (int i = 0; i < dt_category.Rows.Count; i++)
                        {
                            if (cb_category.Text == dt_category.Rows[i][1].ToString())
                            {
                                cb_category.Text = dt_category.Rows[i][0].ToString();
                            }
                        }
                        long harga = Convert.ToInt64(tb_harga.Text.Replace(".", ""));
                        string format = harga.ToString("N0");
                        for (int i = 0; i < dt_filter_product.Rows.Count; i++)
                        {
                            if (dt_filter_product.Rows[i][0].ToString() == selectedid)
                            {
                                dt_filter_product.Rows[i][1] = tb_namaD.Text;
                                dt_filter_product.Rows[i][2] = format;
                                dt_filter_product.Rows[i][3] = tb_stock.Text;
                                dt_filter_product.Rows[i][4] = cb_category.Text;
                                dt_product.Rows[i][1] = tb_namaD.Text;
                                dt_product.Rows[i][2] = format;
                                dt_product.Rows[i][3] = tb_stock.Text;
                                dt_product.Rows[i][4] = cb_category.Text;
                            }
                        }
                        tb_harga.Text = string.Empty;
                        tb_namaD.Text = string.Empty;
                        tb_stock.Text = string.Empty;
                        cb_category.Text = string.Empty;
                        cb_filter.Text = string.Empty;
                        dgv_product.ClearSelection();
                    }
                }
            }
            else
            {
                MessageBox.Show("Input yang lengkap ya");
            }
        }

        private string GetCategoryID(string categoryName)
        {
            foreach (DataRow row in dt_category.Rows)
            {
                if (row["Nama Category"].ToString().Equals(categoryName))
                {
                    return row["ID Category"].ToString();
                }
            }

            return "";
        }

        private void btn_removeP_Click(object sender, EventArgs e)
        {
            if (tb_namaD.Text.Length != 0 || tb_harga.Text.Length != 0 || tb_stock.Text.Length != 0 || cb_category.Text.Length != 0)
            {
                string selectedid = dgv_product.CurrentRow.Cells[0].Value.ToString();
                if (dgv_product.Rows.Count != dt_product.Rows.Count)
                {
                    for (int i = dgv_product.Rows.Count - 1; i >= 0; i--)
                    {
                        dgv_product.Rows.RemoveAt(i);
                    }
                    for (int i = 0; i < dt_product.Rows.Count; i++)
                    {
                        dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                    }
                }
                for (int i = 0; i < dt_filter_product.Rows.Count; i++)
                {
                    if (dt_filter_product.Rows[i][0].ToString() == selectedid)
                    {
                        dt_filter_product.Rows.RemoveAt(i);
                        dt_product.Rows.RemoveAt(i);
                    }
                }
                tb_harga.Text = string.Empty;
                tb_namaD.Text = string.Empty;
                tb_stock.Text = string.Empty;
                cb_category.Text = string.Empty;
                cb_filter.Text = string.Empty;
                dgv_product.ClearSelection();
            }
            else
            {
                MessageBox.Show("Pilih barang terlebih dahulu");
            }
        }

        private void btn_addC_Click(object sender, EventArgs e)
        {
            if (tb_namaC.Text.Length > 0)
            {
                bool benar = false;
                for (int i = 0; i < dgv_category.Rows.Count; i++)
                {
                    if (i < dt_category.Rows.Count && dt_category.Rows[i] != null && dt_category.Rows[i][1] != null && dt_category.Rows[i][1].ToString() == tb_namaC.Text)
                    {
                        benar = true;
                        MessageBox.Show("kategori sudah ada");
                    }
                }
                if (benar == false)
                {
                    int jumlah = dt_category.Rows.Count - 1;
                    int urutan = Convert.ToInt32(dt_category.Rows[jumlah][0].ToString().Substring(1, 1));
                    dt_category.Rows.Add("C" + (urutan + 1), tb_namaC.Text);
                    cb_category.Items.Add(tb_namaC.Text);
                    cb_filter.Items.Add(tb_namaC.Text);
                    tb_namaC.Text = "";
                    dgv_category.ClearSelection();
                }
            }
            else
            {
                MessageBox.Show("Input tidak lengkap");
            }
        }

        private void btn_removeC_Click(object sender, EventArgs e)
        {
            string urutan = "";
            int urut = dgv_category.Rows.Count;
            if (tb_namaC.Text.Length > 0)
            {
                for (int i = 0; i < urut; i++)
                {
                    if (dt_category.Rows[i][1].ToString() == tb_namaC.Text)
                    {
                        urutan = dt_category.Rows[i][0].ToString();
                        dt_category.Rows.RemoveAt(i);
                        cb_category.Items.RemoveAt(i);
                        cb_filter.Items.RemoveAt(i);
                        dgv_category.ClearSelection();
                        break;
                    }
                }
                for (int j = 0; j < dt_product.Rows.Count; j++)
                {
                    if (dt_product.Rows[j][4].ToString() == urutan)
                    {
                        dt_filter_product.Rows.RemoveAt(j);
                        dt_product.Rows.RemoveAt(j);
                        j = -1;
                    }
                }
                tb_namaC.Text = string.Empty;
                dgv_category.ClearSelection();
            }
            else
            {
                MessageBox.Show("Pilih Category terlebih dahulu");
            }
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_harga.Text = string.Empty;
            tb_namaD.Text = string.Empty;
            tb_stock.Text = string.Empty;
            cb_category.Text = string.Empty;
            tb_namaC.Text = string.Empty;
            string pilih = "";
            if (cb_filter.Text.Length > 0)
            {
                for (int i = dgv_product.Rows.Count - 2; i >= 0; i--)
                {
                    dgv_product.Rows.RemoveAt(i);
                }
                for (int i = 0; i < dt_product.Rows.Count; i++)
                {
                    dt_filter_product.Rows.Add(dt_product.Rows[i][0].ToString(), dt_product.Rows[i][1].ToString(), dt_product.Rows[i][2].ToString(), dt_product.Rows[i][3].ToString(), dt_product.Rows[i][4].ToString());
                }
                for (int i = 0; i < dt_category.Rows.Count; i++)
                {
                    if (cb_filter.Text == dt_category.Rows[i][1].ToString())
                    {
                        pilih = dt_category.Rows[i][0].ToString();
                    }
                }
                for (int i = dt_filter_product.Rows.Count - 1; i >= 0; i--)
                {
                    if (dt_product.Rows[i][4].ToString() != pilih)
                    {
                        dt_filter_product.Rows.RemoveAt(i);
                    }
                }
            }
        }
    }
}
