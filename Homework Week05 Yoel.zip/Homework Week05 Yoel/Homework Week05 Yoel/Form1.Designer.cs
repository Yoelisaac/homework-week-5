﻿namespace Homework_Week05_Yoel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_product = new System.Windows.Forms.Label();
            this.lbl_category = new System.Windows.Forms.Label();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.lbl_details = new System.Windows.Forms.Label();
            this.lbl_namaD = new System.Windows.Forms.Label();
            this.lbl_categoryD = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lbl_stock = new System.Windows.Forms.Label();
            this.lbl_namaC = new System.Windows.Forms.Label();
            this.tb_namaD = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.tb_namaC = new System.Windows.Forms.TextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.btn_addP = new System.Windows.Forms.Button();
            this.btn_editP = new System.Windows.Forms.Button();
            this.btn_removeP = new System.Windows.Forms.Button();
            this.btn_addC = new System.Windows.Forms.Button();
            this.btn_removeC = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_product
            // 
            this.lbl_product.AutoSize = true;
            this.lbl_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product.Location = new System.Drawing.Point(12, 18);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(82, 24);
            this.lbl_product.TabIndex = 0;
            this.lbl_product.Text = "Product";
            // 
            // lbl_category
            // 
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(503, 18);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(93, 24);
            this.lbl_category.TabIndex = 1;
            this.lbl_category.Text = "Category";
            // 
            // dgv_product
            // 
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.Location = new System.Drawing.Point(16, 54);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.Size = new System.Drawing.Size(388, 150);
            this.dgv_product.TabIndex = 2;
            this.dgv_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_product_CellClick);
            // 
            // dgv_category
            // 
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.Location = new System.Drawing.Point(507, 54);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.Size = new System.Drawing.Size(240, 150);
            this.dgv_category.TabIndex = 3;
            this.dgv_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_category_CellClick);
            // 
            // lbl_details
            // 
            this.lbl_details.AutoSize = true;
            this.lbl_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_details.Location = new System.Drawing.Point(12, 227);
            this.lbl_details.Name = "lbl_details";
            this.lbl_details.Size = new System.Drawing.Size(72, 24);
            this.lbl_details.TabIndex = 4;
            this.lbl_details.Text = "Details";
            // 
            // lbl_namaD
            // 
            this.lbl_namaD.AutoSize = true;
            this.lbl_namaD.Location = new System.Drawing.Point(13, 271);
            this.lbl_namaD.Name = "lbl_namaD";
            this.lbl_namaD.Size = new System.Drawing.Size(41, 13);
            this.lbl_namaD.TabIndex = 5;
            this.lbl_namaD.Text = "Nama :";
            // 
            // lbl_categoryD
            // 
            this.lbl_categoryD.AutoSize = true;
            this.lbl_categoryD.Location = new System.Drawing.Point(13, 307);
            this.lbl_categoryD.Name = "lbl_categoryD";
            this.lbl_categoryD.Size = new System.Drawing.Size(55, 13);
            this.lbl_categoryD.TabIndex = 6;
            this.lbl_categoryD.Text = "Category :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Location = new System.Drawing.Point(13, 346);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(42, 13);
            this.lbl_harga.TabIndex = 7;
            this.lbl_harga.Text = "Harga :";
            // 
            // lbl_stock
            // 
            this.lbl_stock.AutoSize = true;
            this.lbl_stock.Location = new System.Drawing.Point(13, 387);
            this.lbl_stock.Name = "lbl_stock";
            this.lbl_stock.Size = new System.Drawing.Size(41, 13);
            this.lbl_stock.TabIndex = 8;
            this.lbl_stock.Text = "Stock :";
            // 
            // lbl_namaC
            // 
            this.lbl_namaC.AutoSize = true;
            this.lbl_namaC.Location = new System.Drawing.Point(504, 227);
            this.lbl_namaC.Name = "lbl_namaC";
            this.lbl_namaC.Size = new System.Drawing.Size(41, 13);
            this.lbl_namaC.TabIndex = 9;
            this.lbl_namaC.Text = "Nama :";
            // 
            // tb_namaD
            // 
            this.tb_namaD.Location = new System.Drawing.Point(70, 268);
            this.tb_namaD.Name = "tb_namaD";
            this.tb_namaD.Size = new System.Drawing.Size(334, 20);
            this.tb_namaD.TabIndex = 10;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(70, 343);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(100, 20);
            this.tb_harga.TabIndex = 11;
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(70, 384);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(100, 20);
            this.tb_stock.TabIndex = 12;
            // 
            // tb_namaC
            // 
            this.tb_namaC.Location = new System.Drawing.Point(562, 224);
            this.tb_namaC.Name = "tb_namaC";
            this.tb_namaC.Size = new System.Drawing.Size(185, 20);
            this.tb_namaC.TabIndex = 13;
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(70, 304);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(100, 21);
            this.cb_category.TabIndex = 14;
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(304, 20);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(100, 21);
            this.cb_filter.TabIndex = 15;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(178, 20);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(41, 23);
            this.btn_all.TabIndex = 16;
            this.btn_all.Text = "all";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(244, 19);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(41, 23);
            this.btn_filter.TabIndex = 17;
            this.btn_filter.Text = "filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // btn_addP
            // 
            this.btn_addP.Location = new System.Drawing.Point(192, 352);
            this.btn_addP.Name = "btn_addP";
            this.btn_addP.Size = new System.Drawing.Size(64, 52);
            this.btn_addP.TabIndex = 18;
            this.btn_addP.Text = "Add Product";
            this.btn_addP.UseVisualStyleBackColor = true;
            this.btn_addP.Click += new System.EventHandler(this.btn_addP_Click);
            // 
            // btn_editP
            // 
            this.btn_editP.Location = new System.Drawing.Point(262, 352);
            this.btn_editP.Name = "btn_editP";
            this.btn_editP.Size = new System.Drawing.Size(64, 52);
            this.btn_editP.TabIndex = 19;
            this.btn_editP.Text = "Edit Product";
            this.btn_editP.UseVisualStyleBackColor = true;
            this.btn_editP.Click += new System.EventHandler(this.btn_editP_Click);
            // 
            // btn_removeP
            // 
            this.btn_removeP.Location = new System.Drawing.Point(332, 352);
            this.btn_removeP.Name = "btn_removeP";
            this.btn_removeP.Size = new System.Drawing.Size(64, 52);
            this.btn_removeP.TabIndex = 20;
            this.btn_removeP.Text = "Remove Product";
            this.btn_removeP.UseVisualStyleBackColor = true;
            this.btn_removeP.Click += new System.EventHandler(this.btn_removeP_Click);
            // 
            // btn_addC
            // 
            this.btn_addC.Location = new System.Drawing.Point(575, 268);
            this.btn_addC.Name = "btn_addC";
            this.btn_addC.Size = new System.Drawing.Size(64, 52);
            this.btn_addC.TabIndex = 21;
            this.btn_addC.Text = "Add Category";
            this.btn_addC.UseVisualStyleBackColor = true;
            this.btn_addC.Click += new System.EventHandler(this.btn_addC_Click);
            // 
            // btn_removeC
            // 
            this.btn_removeC.Location = new System.Drawing.Point(670, 268);
            this.btn_removeC.Name = "btn_removeC";
            this.btn_removeC.Size = new System.Drawing.Size(64, 52);
            this.btn_removeC.TabIndex = 22;
            this.btn_removeC.Text = "Remove Category";
            this.btn_removeC.UseVisualStyleBackColor = true;
            this.btn_removeC.Click += new System.EventHandler(this.btn_removeC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_removeC);
            this.Controls.Add(this.btn_addC);
            this.Controls.Add(this.btn_removeP);
            this.Controls.Add(this.btn_editP);
            this.Controls.Add(this.btn_addP);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.tb_namaC);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_namaD);
            this.Controls.Add(this.lbl_namaC);
            this.Controls.Add(this.lbl_stock);
            this.Controls.Add(this.lbl_harga);
            this.Controls.Add(this.lbl_categoryD);
            this.Controls.Add(this.lbl_namaD);
            this.Controls.Add(this.lbl_details);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.lbl_category);
            this.Controls.Add(this.lbl_product);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_product;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.Label lbl_details;
        private System.Windows.Forms.Label lbl_namaD;
        private System.Windows.Forms.Label lbl_categoryD;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Label lbl_stock;
        private System.Windows.Forms.Label lbl_namaC;
        private System.Windows.Forms.TextBox tb_namaD;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.TextBox tb_namaC;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.Button btn_addP;
        private System.Windows.Forms.Button btn_editP;
        private System.Windows.Forms.Button btn_removeP;
        private System.Windows.Forms.Button btn_addC;
        private System.Windows.Forms.Button btn_removeC;
    }
}

